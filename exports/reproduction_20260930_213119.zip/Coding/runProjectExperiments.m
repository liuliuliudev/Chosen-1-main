function resultRoot = runProjectExperiments(resultRoot)
%RUN_ALL 完整运行写入新目录；不覆盖已有实验。
root = fileparts(mfilename('fullpath'));
folders = {'config','src/dynamics','src/environment','src/control', ...
    'src/propagation','src/analysis','src/visualization','scripts','tests'};
for k = 1:numel(folders), addpath(fullfile(root,folders{k})); end
if nargin < 1 || isempty(resultRoot)
    resultRoot = fullfile(root,'results', ...
        ['run_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
end
resultRoot = char(java.io.File(char(resultRoot)).getCanonicalPath());
allowed = char(java.io.File(fullfile(root,'results')).getCanonicalPath());
if ~startsWith(lower(resultRoot),[lower(allowed) filesep]) || ...
        isfolder(resultRoot) || isfile(resultRoot)
    error('RunAll:UnsafeOutput','Choose a NEW directory under Coding/results.');
end
logDir = fullfile(resultRoot,'logs');
if ~isfolder(logDir), mkdir(logDir); end
% 每次运行创建带时间戳的日志，便于回查命令窗口输出。
diary(fullfile(logDir,['run_all_' char(datetime('now','Format','yyyyMMdd_HHmmss')) '.txt']));
diary on
cleanup = onCleanup(@() diary('off')); %#ok<NASGU>
run_tests();
p = baseline_case();
out = fullfile(resultRoot,'tables');
run_input_audit(out);
% 先生成基准策略结果，再检查数值精度和各类参数、故障情景。
[baselineResults,~] = run_baselines(p,out);
% 工程预算只读取基准案例结果，不向传播器或控制策略反馈资源结论。
run_engineering_audit(p,baselineResults,out);
switchDiagnostic = analyzeSwitchNeighborhood(baselineResults{4});
writetable(switchDiagnostic,fullfile(out,'switch_diagnostic.csv'));
disp(switchDiagnostic);
run_numerical_check(p,out);
run_switch_scan(p,out);
run_sensitivity(p,out);
run_fault_cases(p,out);
% 人工观测情景单独核查监督器逻辑；下一步另跑监督轨道案例。
run_supervisor_scenarios(p,out);
% 单独保存监督器驱动的概念轨道案例，不改变四种固定对照策略。
runCaseGroup('supervised',p,out);
runCaseGroup('hardware',p,out);
run_power_screen(p,out);
[powerResults,~] = runCaseGroup('power',p,out);
powerId = strings(numel(powerResults),1);
minimumBattery_Wh = zeros(numel(powerResults),1);
unmetBaseEnergy_Wh = minimumBattery_Wh;
for k = 1:numel(powerResults)
    powerId(k) = string(powerResults{k}.config.case.id);
    minimumBattery_Wh(k) = powerResults{k}.power.minimumBattery_Wh;
    unmetBaseEnergy_Wh(k) = powerResults{k}.power.unmetBaseEnergy_Wh;
end
writetable(table(powerId,minimumBattery_Wh,unmetBaseEnergy_Wh), ...
    fullfile(out,'power_resources.csv'));
run_power_numerical_check(p,out);
% 各组结果全部落盘后，逐案例检查候选硬件假设是否仍适用。
run_case_resource_audit(out,p);
% 第四个基准案例 P 的轨迹用于生成高度随时间变化的动画。
makeOrbitVideo(baselineResults{4},fullfile(resultRoot,'videos','P_altitude.mp4'));
diary off
% 日志关闭后记录实际文件状态，并保存本次参数与预算快照。
buildEvidenceIndex(root,p,resultRoot);
fprintf('Run output: %s\n',resultRoot);
end
